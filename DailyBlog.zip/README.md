USERS - name, email,username,password,gender,role[admin, user]
POSTS - cover image, title, description, content,slug
CATEGORY - title,slug
COMMENTS - user, comment
