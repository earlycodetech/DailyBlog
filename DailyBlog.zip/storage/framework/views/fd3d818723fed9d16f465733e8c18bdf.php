
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container my-5">
            <div class="card mx-auto" style="max-width: 600px;">
                <form action="<?php echo e(route('contact.submit')); ?>" method="POST"  class="card-body">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="" class="form-label">Full Name</label>
                        <input type="text" name="name" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label">Email</label>
                        <input type="email" name="email" class="form-control">
                    </div>

                    <div class="mb-3">
                        <textarea name="message" rows="5" class="form-control"></textarea>
                    </div>

                    <div class="text-center mb-3">
                        <button class="btn btn-success">
                            Send Message
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\DailyBlog\resources\views/contact.blade.php ENDPATH**/ ?>