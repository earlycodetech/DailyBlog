<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="<?php echo e(route('homepage')); ?>">
            <img src="<?php echo e(asset('logo.png')); ?>" width="80" alt="Logo">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?php echo e(route('homepage')); ?>">Home</a>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        Categories
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo e(route('categories.index')); ?>">All Categories</a></li>
                        <li><a class="dropdown-item" href="#">Another action</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="#">Something else here</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('contact.page')); ?>">Contact Us</a>
                </li>
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>"> Sign In <i class="fa-solid fa-sign-in"></i> </a>
                    </li>
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <?php echo e(auth()->user()->username); ?>

                        </a>
                        <ul class="dropdown-menu">
                            <?php if(auth()->user()->role === 'user'): ?>
                                
                                <li>
                                    <a class="dropdown-item" href="#">
                                       <i class="fa-solid fa-newspaper"></i> Saved Posts
                                    </a>
                                </li>
                            <?php else: ?>
                            
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('categories.index')); ?>">
                                    Categories
                                </a>
                            </li>
                                <li>
                                    <a class="dropdown-item" href="<?php echo e(route('posts.index')); ?>">
                                        Posts
                                    </a>
                                </li>
                            <?php endif; ?>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li>
                                <form action="<?php echo e(route('logout')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button class="dropdown-item"> <i class="fa-solid fa-power-off"></i> Logout </button>
                                </form>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
            <form class="d-flex" role="search">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">
                    <i class="fa-solid fa-search"></i>
                </button>
            </form>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\DailyBlog\resources\views/partials/navbar.blade.php ENDPATH**/ ?>