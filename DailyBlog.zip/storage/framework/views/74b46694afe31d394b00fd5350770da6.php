
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container my-5">
            <div class="card border-0 shadow">
                <div class="card-body">
                    <div class="text-end">
                        <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary"> Create New Category </a>
                    </div>

                    <div class="my-3 table-responsive">
                        <table class="table table-dark">
                            <thead>
                                <tr>
                                    <th scope="row">Title</th>
                                    <th scope="row">Date Created</th>
                                    <th scope="row">Last Updated</th>
                                    <th>
                                        <i class="fa-solid fa-ellipsis-h"></i>
                                    </th>
                                </tr>
                            </thead>


                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td> <?php echo e($cat->title); ?> </td>
                                        <td> <?php echo e($cat->created_at->format('jS M. Y h:i a')); ?> </td>
                                        <td> <?php echo e($cat->updated_at->diffForHumans()); ?> </td>
                                        <td class="d-flex gap-3">
                                            <a href="<?php echo e(route('categories.show', ['category' => $cat->id])); ?>" class="btn btn-warning btn-sm">
                                                <i class="fa-solid fa-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('categories.edit', ['category' => $cat->slug])); ?>"
                                                class="btn btn-primary btn-sm">
                                                <i class="fa-solid fa-edit"></i>
                                            </a>
                                            <form action="<?php echo e(route('categories.destroy', ['category' => $cat->id])); ?>"
                                                method="post" onsubmit="return confirm('Are you sure?')"
                                                >
                                                <?php echo csrf_field(); ?> 
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-danger btn-sm">
                                                    <i class="fa-solid fa-trash-alt"></i>
                                                </button>
                                            </form>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center"> No Category Created Yet </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>

                        <div class="p-2">
                            <?php echo $categories->links('pagination::bootstrap-5'); ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\DailyBlog\resources\views/categories/index.blade.php ENDPATH**/ ?>