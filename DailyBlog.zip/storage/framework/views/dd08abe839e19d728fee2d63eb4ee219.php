
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container my-5">
            <div class="card border-0 shadow">
                <div class="card-body">
                    <div class="text-end">
                        <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary"> Create New Post </a>
                    </div>

                    <div class="my-3 table-responsive">
                        <table class="table table-dark">
                            <thead>
                                <tr>
                                    <th scope="row">Cover</th>
                                    <th scope="row">Title</th>
                                    <th scope="row">Date Created</th>
                                    <th scope="row">Last Updated</th>
                                    <th>
                                        <i class="fa-solid fa-ellipsis-h"></i>
                                    </th>
                                </tr>
                            </thead>


                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <img src="<?php echo e(asset($post->cover_image)); ?>" style="width: 100px; height: 80px;"
                                                class="object-fit-contain rounded-lg ratio-16x9" alt="">
                                        </td>

                                        <td>
                                            <?php echo e($post->title); ?>

                                        </td>
                                        <td>
                                            <?php echo e($post->created_at->format('jS M. Y h:i a')); ?>

                                        </td>
                                        <td>
                                            <?php echo e($post->updated_at->diffForHumans()); ?>

                                        </td>
                                        <td>
                                            <div class="d-flex gap-3">
                                                <a href="<?php echo e(route('posts.edit', ['post' => $post->id])); ?>"
                                                    class="btn btn-sm btn-primary">
                                                    <i class="fa-solid fa-edit"></i>
                                                </a>

                                                <form action="<?php echo e(route('posts.destroy', ['post' => $post->id])); ?>"
                                                    onsubmit="return confirm('Are you sure?')" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button class="btn btn-danger btn-sm">
                                                        <i class="fa-solid fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center"> No Post(s) Created Yet </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>

                        <div class="p-2">
                            <?php echo $posts->links('pagination::bootstrap-5'); ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\DailyBlog\resources\views/posts/index.blade.php ENDPATH**/ ?>