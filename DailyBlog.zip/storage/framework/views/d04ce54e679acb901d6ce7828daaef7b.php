
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container my-5">
            <div class="card border-0 shadow mx-auto bg-white" style="max-width: 900px;">
                <div class="card-header bg-white">
                    <h2>Edit Post</h2>
                </div>

                <form class="card-body row" method="POST" action="<?php echo e(route('posts.update', ['post' => $post->id])); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>

                    <div class="text-end my-4">
                        <img src="<?php echo e(asset($post->cover_image)); ?>" width="150" alt="">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="title" class="form-label">Title</label>
                        <input type="text" name="title" value="<?php echo e($post->title); ?>" id="title" class="form-control bg-white">
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="cover" class="form-label">Cover Image</label>
                        <input type="file" id="cover" name="cover_image" accept="image/*" class="form-control bg-white">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="category" class="form-label">Category</label>
                        <select id="category" name="category" class="form-select bg-white" required> 
                            <option value="">__Select Category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->id); ?>" <?php echo e($post->category_id == $cat->id ? "selected" : ""); ?>>
                                    <?php echo e($cat->title); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="abstract" class="form-label">Abstract</label>
                       <textarea name="abstract" id="abstract"  rows="3" class="form-control bg-white"><?php echo e($post->abstract); ?></textarea>
                    </div>

                    <div class="col-12 my-3">
                        <textarea name="content" id="ck-edit" class="form-control bg-white" rows="10"><?php echo e($post->content); ?></textarea>
                    </div>

                    <div class="text-center">
                        <button class="btn btn-primary">
                            Update Post
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\DailyBlog\resources\views/posts/edit.blade.php ENDPATH**/ ?>