
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container my-5">
            <h1> Edit: <?php echo e($category->title); ?> </h1>

            <form action="<?php echo e(route('categories.update', ['category' =>  $category->id])); ?>" method="post" class="card border-0 bg-white shadow">
                <?php echo csrf_field(); ?> 
                <?php echo method_field('PATCH'); ?>

               
                <div class="card-body">
                    <label for="" class="form-label">Title</label>
                    <input type="text" name="title" value="<?php echo e($category->title); ?>" class="form-control bg-white <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="small fw-bold text-danger">
                            <i class="fa-solid fa-exclamation-triangle"></i> <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="my-3">
                        <button class="btn btn-primary">Update</button>
                    </div>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\DailyBlog\resources\views/categories/edit.blade.php ENDPATH**/ ?>