
<?php $__env->startSection('content'); ?>
    <section class="my-5">
        <article class="container pb-5">
            <div class="card bg-white mx-auto shadow-sm" style="max-width: 900px;">
                <div class="card-body">
                    <header class="text-center">
                        <h1 class="fw-bold mb-3">
                            <?php echo e($post->title); ?>

                        </h1>

                        <h6 class="mb-3 text-secondary fw-semibold">
                            <i class="fa-solid fa-calendar-day"></i>
                            <?php echo e($post->created_at->format('jS M. Y')); ?>

                        </h6>

                        <p class="fst-italic text-secondary small lh-lg px-md-5">
                            <?php echo e($post->abstract); ?>

                        </p>

                        <img src="<?php echo e(asset($post->cover_image)); ?>" class="w-100 ratio-16x9 mb-3 object-fit-cover"
                            style="height: 250px; min-height: 400px;" alt="<?php echo e($post->title); ?>">

                        <h6 class="mb-3 text-secondary fw-semibold">
                            <i class="fa-solid fa-newspaper"></i>
                            <?php echo e($post->category->title); ?>

                        </h6>

                    </header>


                    <div class="my-3 px-md-5 ck-content">
                        <?php echo $post->content; ?>

                    </div>
                </div>
                <div class="card-footer bg-white" id="comments">
                    <div class="d-flex justify-content-between align-items-center mb-5 border-bottom pb-2">
                        <p class="h5 fw-bold m-0">
                            Comments
                        </p>

                        <?php echo $__env->make('partials.new-comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                    <div class="">
                        <ul class="list-group list-group-flush">
                            <?php
                                $comments = $post->comments()->latest()->get();
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="list-group-item bg-white">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <?php if($comment->user): ?>
                                                <p class="fw-bold h5 m-0"> <?php echo e($comment->user->name); ?> </p>
                                                <p class="m-0 small text-sencondary fst-italic"><?php echo e($comment->user->email); ?>

                                                </p>
                                            <?php else: ?>
                                                <p class="fw-bold h5 m-0"> DELETED ACCOUNT </p>
                                            <?php endif; ?>
                                        </div>

                                        <p class="small fw-semibold text-secondary">
                                            <?php echo e($comment->created_at->diffForHumans()); ?> </p>
                                    </div>

                                    <div>
                                        <p>
                                            <?php echo e($comment->comment); ?>

                                        </p>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="h4 fw-bold text-center">
                                    Be the first to comment on this post...
                                </p>
                            <?php endif; ?>
                        </ul>
                    </div>

                </div>



                
                <form action="<?php echo e(route('new.like', ['slug' => $post->slug])); ?>" method="POST" id="likes">
                    <?php echo csrf_field(); ?>
                    
                    <button class="btn <?php echo e($hasLiked ? 'btn-primary' : 'btn-secondary'); ?>">
                        <i class="fa-solid fa-thumbs-up fs-1"></i>
                    </button>


                    <p class="text-secondary">
                        <?php
                            $total_likes = $post->likes->count();
                            if ($total_likes < 1000) {
                                $likes = $total_likes;
                            } else {
                                $likes = strval($total_likes);
                                $likes = Str::substr($likes, 0, 1) . 'k+';
                            }
                        ?>

                        <?php echo $likes; ?>

                        <?php echo e($post->likes->count() <= 1 ? 'like' : 'likes'); ?>

                    </p>
                </form>
                
            </div>
        </article>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\DailyBlog\resources\views/posts/read.blade.php ENDPATH**/ ?>