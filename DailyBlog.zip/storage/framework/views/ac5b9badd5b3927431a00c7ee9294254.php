<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
</head>
<body>
    <h1>You have a new Contact</h1>
    <ul>
        <li>
            Name: <?php echo e($data['name']); ?>

        </li>
        <li>
            Email: <?php echo e($data['email']); ?>

        </li>
        <li>
            <u>Message</u> 
            <br><br>

            <?php echo e($data['message']); ?>

        </li>
    </ul>
</body>
</html><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\DailyBlog\resources\views/mail/contact-mail.blade.php ENDPATH**/ ?>